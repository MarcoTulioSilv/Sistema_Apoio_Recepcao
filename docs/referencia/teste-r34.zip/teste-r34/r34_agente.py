"""Teste do R-34 — passos 3 e 4: agente local e chamada a partir do Chrome (AD-17, DD-39).

Sobe dois servidores nesta estação:
  * a PÁGINA de teste, em http://0.0.0.0:8000 — faz o papel do servidor do SAR;
  * o AGENTE, só em http://127.0.0.1:8765 — faz o papel do agente de captura.

O agente só aceita chamadas das origens permitidas (cabeçalho Origin), responde à verificação de
acesso à rede local do Chrome e devolve a imagem digitalizada para a página, em memória.
Nada é gravado em disco.

Uso no PowerShell, na pasta do teste:
    py r34_agente.py                 # com o scanner (precisa do pywin32)
    py r34_agente.py --simulado      # sem scanner: devolve uma imagem de teste, para testar só o navegador
"""
from __future__ import annotations

import argparse
import base64
import json
import socket
import struct
import threading
import time
import zlib
from http.server import BaseHTTPRequestHandler, HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

PORTA_PAGINA = 8000
PORTA_AGENTE = 8765
PASTA = Path(__file__).resolve().parent


def ip_da_rede_local() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))  # não envia nada; só descobre a interface de saída
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def png_de_teste(largura: int = 1240, altura: int = 1754) -> bytes:
    """PNG cinza simples, gerado em memória, para o modo simulado (A4 a 150 dpi)."""
    linha = b"\x00" + bytes((x // 8) % 256 for x in range(largura))
    bruto = linha * altura
    def bloco(tipo, dados):
        return struct.pack(">I", len(dados)) + tipo + dados + struct.pack(">I", zlib.crc32(tipo + dados) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + bloco(b"IHDR", struct.pack(">IIBBBBB", largura, altura, 8, 0, 0, 0, 0))
            + bloco(b"IDAT", zlib.compress(bruto, 6)) + bloco(b"IEND", b""))


class Agente(BaseHTTPRequestHandler):
    origens: set[str] = set()
    simulado = False
    trava = threading.Lock()

    def log_message(self, fmt, *args):  # registro enxuto, sem conteúdo
        pass

    def _registrar(self, resultado: str) -> None:
        print(f"[agente] {self.command} {self.path}  Origin={self.headers.get('Origin')}  "
              f"Sec-Fetch-Site={self.headers.get('Sec-Fetch-Site')}  "
              f"Rede-local-pedida={self.headers.get('Access-Control-Request-Private-Network') or self.headers.get('Access-Control-Request-Local-Network')}"
              f"  -> {resultado}")

    def _cors(self) -> bool:
        origem = self.headers.get("Origin")
        if origem not in self.origens:
            return False
        self.send_header("Access-Control-Allow-Origin", origem)
        self.send_header("Vary", "Origin")
        return True

    def do_OPTIONS(self):  # verificação prévia do Chrome (CORS e acesso à rede local)
        if self.headers.get("Origin") not in self.origens:
            self._registrar("RECUSADO: origem não permitida")
            self.send_response(403); self.end_headers(); return
        self.send_response(204)
        self._cors()
        self.send_header("Access-Control-Allow-Methods", "GET, POST")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Allow-Local-Network", "true")
        self.send_header("Access-Control-Max-Age", "60")
        self.end_headers()
        self._registrar("verificação prévia aceita")

    def _json(self, codigo: int, corpo: dict) -> None:
        dados = json.dumps(corpo, ensure_ascii=False).encode()
        self.send_response(codigo)
        self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(dados)))
        self.end_headers()
        self.wfile.write(dados)

    def do_GET(self):
        if self.headers.get("Origin") not in self.origens:
            self._registrar("RECUSADO: origem não permitida")
            self.send_response(403); self.end_headers(); return
        if self.path == "/status":
            self._registrar("status")
            self._json(200, {"agente": "ok", "simulado": self.simulado})
        else:
            self.send_response(404); self.end_headers()

    def do_POST(self):
        if self.headers.get("Origin") not in self.origens:
            self._registrar("RECUSADO: origem não permitida")
            self.send_response(403); self.end_headers(); return
        if self.path != "/capturar":
            self.send_response(404); self.end_headers(); return
        tamanho = int(self.headers.get("Content-Length") or 0)
        pedido = json.loads(self.rfile.read(tamanho) or b"{}")
        if not self.trava.acquire(blocking=False):
            self._json(409, {"erro": "captura em andamento"}); return
        try:
            inicio = time.perf_counter()
            if self.simulado:
                img = png_de_teste()
                paginas = [{"bytes": len(img), "largura": 1240, "altura": 1754, "formato": "png", "ms": 0, "_dados": img}]
            else:
                import r34_scanner
                r = r34_scanner.digitalizar(pedido.get("modo", "vidro"), int(pedido.get("dpi", 300)),
                                            pedido.get("cor", "cinza"), pedido.get("formato", "png"))
                paginas = r["paginas"]
            saida = []
            for pg in paginas:
                dados = pg.pop("_dados")
                mime = {"png": "image/png", "jpeg": "image/jpeg", "tiff": "image/tiff", "bmp": "image/bmp"}[pg["formato"]]
                pg["imagem"] = f"data:{mime};base64," + base64.b64encode(dados).decode()
                saida.append(pg)
            total = round((time.perf_counter() - inicio) * 1000)
            self._registrar(f"{len(saida)} página(s) em {total} ms")
            self._json(200, {"paginas": saida, "total_ms": total})
        except Exception as erro:
            self._registrar(f"ERRO: {erro}")
            self._json(500, {"erro": str(erro)})
        finally:
            self.trava.release()


class Pagina(SimpleHTTPRequestHandler):
    def __init__(self, *a, **k):
        super().__init__(*a, directory=str(PASTA), **k)

    def log_message(self, fmt, *args):
        pass


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--simulado", action="store_true")
    a = p.parse_args()
    ip = ip_da_rede_local()
    Agente.simulado = a.simulado
    Agente.origens = {f"http://localhost:{PORTA_PAGINA}", f"http://127.0.0.1:{PORTA_PAGINA}", f"http://{ip}:{PORTA_PAGINA}"}

    agente = HTTPServer(("127.0.0.1", PORTA_AGENTE), Agente)   # só no próprio computador
    pagina = HTTPServer(("0.0.0.0", PORTA_PAGINA), Pagina)
    threading.Thread(target=pagina.serve_forever, daemon=True).start()
    print("Agente de teste do R-34" + (" (SIMULADO, sem scanner)" if a.simulado else ""))
    print(f"  Agente:  http://127.0.0.1:{PORTA_AGENTE}  (só aceita: {', '.join(sorted(Agente.origens))})")
    print(f"  Abra no Chrome, nesta ordem:")
    print(f"    Fase A: http://localhost:{PORTA_PAGINA}/r34_teste.html")
    print(f"    Fase B: http://{ip}:{PORTA_PAGINA}/r34_teste.html")
    print("  Ctrl+C para encerrar.\n")
    try:
        agente.serve_forever()
    except KeyboardInterrupt:
        print("\nEncerrado.")


if __name__ == "__main__":
    main()
