# Teste do R-34 - passo 1: diagnostico da estacao da recepcao.
# Rodar no PowerShell (nao precisa ser administrador):
#   powershell -ExecutionPolicy Bypass -File .\r34_diagnostico.ps1
# Arquivo so com caracteres ASCII, para funcionar em qualquer codificacao do PowerShell.
# Nada e gravado em disco alem do arquivo diagnostico_r34.txt, que nao contem dado de paciente.

$saida = @()
function Anotar($titulo, $valor) { $script:saida += "== $titulo"; $script:saida += ($valor | Out-String).TrimEnd(); $script:saida += "" }

Anotar "Data" (Get-Date -Format "yyyy-MM-dd HH:mm")
Anotar "Windows" ((Get-CimInstance Win32_OperatingSystem) | Select-Object Caption, Version, OSArchitecture | Format-List)

# Scanner visto pelo Windows (Plug and Play)
Anotar "Dispositivos de imagem (PnP)" (Get-PnpDevice -Class Image -ErrorAction SilentlyContinue |
    Select-Object Status, FriendlyName, InstanceId | Format-Table -AutoSize)

# Scanner visto pelo WIA, que e o que o agente usa (AD-17)
try {
    $dm = New-Object -ComObject WIA.DeviceManager
    $lista = foreach ($info in $dm.DeviceInfos) {
        $p = @{}
        foreach ($prop in $info.Properties) { $p[$prop.Name] = $prop.Value }
        [pscustomobject]@{ Nome = $p['Name']; Fabricante = $p['Manufacturer']; Tipo = $info.Type; Id = $info.DeviceID }
    }
    if ($lista) { Anotar "Dispositivos WIA" ($lista | Format-Table -AutoSize) }
    else { Anotar "Dispositivos WIA" "NENHUM dispositivo WIA encontrado. Confira o driver do fabricante." }
} catch { Anotar "Dispositivos WIA" "Falha ao abrir o WIA: $($_.Exception.Message)" }

# Chrome
$chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
            "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
            "$env:LocalAppData\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
Anotar "Chrome" ($(if ($chrome) { (Get-Item $chrome).VersionInfo.ProductVersion } else { "nao encontrado" }))

# Python
try { Anotar "Python" (& py --version 2>&1) } catch { Anotar "Python" "py launcher nao encontrado" }
try { Anotar "pywin32" (& py -c "import win32com.client, pythoncom; print('instalado')" 2>&1) } catch { Anotar "pywin32" "nao verificado" }

# Endereco na rede local (para o passo 4)
Anotar "Enderecos IPv4" (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object { $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*" } |
    Select-Object InterfaceAlias, IPAddress | Format-Table -AutoSize)

$saida | Tee-Object -FilePath ".\diagnostico_r34.txt"
Write-Host "`nDiagnostico salvo em diagnostico_r34.txt"
