"""Teste do R-34 — passo 2: digitalização pelo WIA, só em memória (AD-17, SEG-28).

Uso no PowerShell, na pasta do teste:
    py r34_scanner.py --listar
    py r34_scanner.py --modo vidro
    py r34_scanner.py --modo alimentador
    py r34_scanner.py --modo alimentador --folhas 3

Nenhuma imagem é gravada em disco. O script grava só resultado_r34_scanner.json, com tamanhos e tempos.
Use folhas sem dado de paciente: página em branco impressa, texto de teste, formulário vazio.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime

# Identificadores do WIA (Windows Image Acquisition)
FORMATOS = {
    "png": "{B96B3CAF-0728-11D3-9D7B-0000F81EF32E}",
    "jpeg": "{B96B3CAE-0728-11D3-9D7B-0000F81EF32E}",
    "tiff": "{B96B3CB1-0728-11D3-9D7B-0000F81EF32E}",
    "bmp": "{B96B3CAB-0728-11D3-9D7B-0000F81EF32E}",
}
TIPO_SCANNER = 1
PROP_INTENCAO_COR = "6146"      # 1 = cor, 2 = tons de cinza, 4 = preto e branco
PROP_RESOLUCAO_H = "6147"
PROP_RESOLUCAO_V = "6148"
PROP_SELECAO_ALIMENTACAO = "3088"   # no dispositivo: 1 = alimentador, 2 = vidro
PROP_SITUACAO_ALIMENTACAO = "3087"  # no dispositivo: bit 1 = papel no alimentador
PROP_PAGINAS = "3096"               # no dispositivo: páginas por transferência
ERRO_SEM_PAPEL = -2145320957        # 0x80210003, WIA_ERROR_PAPER_EMPTY
INTENCOES = {"cor": 1, "cinza": 2, "pb": 4}


def _wia():
    try:
        import pythoncom  # noqa: F401
        import win32com.client
    except ImportError:
        sys.exit("pywin32 não instalado. Rode: py -m pip install pywin32")
    return win32com.client


def _definir(propriedades, ident: str, valor) -> bool:
    for p in propriedades:
        if str(p.PropertyID) == ident:
            try:
                p.Value = valor
                return True
            except Exception:
                return False
    return False


def _ler(propriedades, ident: str):
    for p in propriedades:
        if str(p.PropertyID) == ident:
            return p.Value
    return None


def listar() -> list[dict]:
    w = _wia()
    dm = w.Dispatch("WIA.DeviceManager")
    saida = []
    for i in range(1, dm.DeviceInfos.Count + 1):
        info = dm.DeviceInfos.Item(i)
        props = {p.Name: p.Value for p in info.Properties}
        saida.append({"indice": i, "nome": props.get("Name"), "fabricante": props.get("Manufacturer"),
                      "tipo": "scanner" if info.Type == TIPO_SCANNER else f"outro ({info.Type})"})
    return saida


def conectar(indice: int | None):
    w = _wia()
    dm = w.Dispatch("WIA.DeviceManager")
    scanners = [dm.DeviceInfos.Item(i) for i in range(1, dm.DeviceInfos.Count + 1)
                if dm.DeviceInfos.Item(i).Type == TIPO_SCANNER]
    if not scanners:
        raise RuntimeError("Nenhum scanner WIA encontrado")
    info = scanners[(indice or 1) - 1]
    return info.Connect()


def codigo_erro(erro) -> int | None:
    """Código WIA de um erro do pywin32 (o WIA costuma vir dentro do excepinfo)."""
    args = getattr(erro, "args", ())
    if len(args) > 2 and isinstance(args[2], tuple) and len(args[2]) > 5:
        return args[2][5]
    return args[0] if args and isinstance(args[0], int) else None


def formato_real(dados: bytes) -> str:
    """Formato pelos primeiros bytes: alguns drivers ignoram o formato pedido."""
    if dados[:2] == b"BM":
        return "bmp"
    if dados[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if dados[:2] == b"\xff\xd8":
        return "jpeg"
    if dados[:4] in (b"II*\x00", b"MM\x00*"):
        return "tiff"
    return "desconhecido"


def tamanhos_comprimidos(dados: bytes) -> dict:
    """Quanto a página ficaria depois de comprimida em memória (precisa do Pillow)."""
    try:
        import io
        from PIL import Image
    except ImportError:
        return {"compressao": "Pillow não instalado"}
    img = Image.open(io.BytesIO(dados))
    saida = {"modo_imagem": img.mode}
    for fmt, opcoes in (("png", {"compress_level": 6}), ("jpeg", {"quality": 90})):
        buf = io.BytesIO()
        inicio = time.perf_counter()
        (img if img.mode in ("L", "RGB") else img.convert("RGB")).save(buf, fmt.upper(), **opcoes)
        saida[f"{fmt}_kb"] = round(len(buf.getvalue()) / 1024)
        saida[f"ms_conversao_{fmt}"] = round((time.perf_counter() - inicio) * 1000)
    return saida


def _transferir(item, formato: str) -> tuple[bytes, int, int, str]:
    """Transfere uma página. Devolve (bytes, largura, altura, formato_real)."""
    ultimo = None
    for fmt in dict.fromkeys((formato, "png", "bmp")):
        try:
            imagem = item.Transfer(FORMATOS[fmt])
            dados = bytes(imagem.FileData.BinaryData)
            return dados, int(imagem.Width), int(imagem.Height), formato_real(dados)
        except Exception as erro:
            if codigo_erro(erro) == ERRO_SEM_PAPEL:
                raise
            ultimo = erro  # formato não suportado pelo driver: tenta o próximo
    raise ultimo


def digitalizar(modo: str, dpi: int, cor: str, formato: str, indice: int | None = None) -> dict:
    """Digitaliza pelo vidro (uma página) ou pelo alimentador (até acabar o papel)."""
    import pythoncom
    pythoncom.CoInitialize()
    dispositivo = conectar(indice)
    if modo == "alimentador":
        ok = _definir(dispositivo.Properties, PROP_SELECAO_ALIMENTACAO, 1)
        _definir(dispositivo.Properties, PROP_PAGINAS, 1)
        if not ok:
            raise RuntimeError("O driver não aceitou selecionar o alimentador pela propriedade 3088")
    else:
        _definir(dispositivo.Properties, PROP_SELECAO_ALIMENTACAO, 2)

    item = dispositivo.Items(1)
    _definir(item.Properties, PROP_INTENCAO_COR, INTENCOES[cor])
    _definir(item.Properties, PROP_RESOLUCAO_H, dpi)
    _definir(item.Properties, PROP_RESOLUCAO_V, dpi)

    paginas, inicio_total = [], time.perf_counter()
    while True:
        inicio = time.perf_counter()
        try:
            dados, largura, altura, fmt = _transferir(item, formato)
        except Exception as erro:
            if modo == "alimentador" and codigo_erro(erro) == ERRO_SEM_PAPEL:
                if paginas:
                    break  # acabou o papel: fim normal do lote
                raise RuntimeError("Alimentador sem papel") from erro
            raise RuntimeError(f"Falha na transferência: {erro}") from erro
        ms = round((time.perf_counter() - inicio) * 1000)
        paginas.append({"bytes": len(dados), "largura": largura, "altura": altura, "formato": fmt,
                        "formato_pedido": formato, "ms": ms, **tamanhos_comprimidos(dados), "_dados": dados})
        if modo == "vidro":
            break
        if len(paginas) >= 50:
            break  # proteção do teste
    return {"modo": modo, "dpi": dpi, "cor": cor, "paginas": paginas,
            "total_ms": round((time.perf_counter() - inicio_total) * 1000),
            "situacao_alimentador": _ler(dispositivo.Properties, PROP_SITUACAO_ALIMENTACAO)}


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--listar", action="store_true")
    p.add_argument("--modo", choices=["vidro", "alimentador"], default="vidro")
    p.add_argument("--dpi", type=int, default=300)
    p.add_argument("--cor", choices=list(INTENCOES), default="cinza")
    p.add_argument("--formato", choices=list(FORMATOS), default="png")
    p.add_argument("--scanner", type=int, default=None, help="índice, se houver mais de um")
    p.add_argument("--folhas", type=int, default=None, help="quantas folhas você colocou no alimentador")
    a = p.parse_args()

    if a.listar:
        print(json.dumps(listar(), ensure_ascii=False, indent=2))
        return

    r = digitalizar(a.modo, a.dpi, a.cor, a.formato, a.scanner)
    for pg in r["paginas"]:
        pg.pop("_dados")  # a imagem existiu só em memória; nada vai para o disco
    r["quando"] = datetime.now().isoformat(timespec="seconds")
    if a.folhas is not None:
        r["folhas_colocadas"] = a.folhas
    print(json.dumps(r, ensure_ascii=False, indent=2))
    with open("resultado_r34_scanner.json", "a", encoding="utf-8") as f:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")
    n = len(r["paginas"])
    print(f"\n{n} página(s), {r['total_ms'] / 1000:.1f} s no total. "
          f"Maior página: {max(pg['bytes'] for pg in r['paginas']) / 1024:.0f} KB em {r['paginas'][0]['formato']}"
          + (f" ({r['paginas'][0].get('png_kb')} KB em PNG). " if 'png_kb' in r['paginas'][0] else ". ")
          +
          "Resultado acrescentado a resultado_r34_scanner.json")
    if a.folhas is not None:
        situacao = "OK" if a.folhas == n else "DIFERENTE — anote"
        print(f"Folhas colocadas: {a.folhas}; páginas lidas: {n} -> {situacao}")


if __name__ == "__main__":
    main()
